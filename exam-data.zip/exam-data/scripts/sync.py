import os
print('syncing', os.getcwd())
