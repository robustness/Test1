#!/bin/bash
# remove temporary files
rm -rf /tmp/stage
